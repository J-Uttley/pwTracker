<?php
$connect=mysqli_connect('213.171.200.84','apiRootUser','apiR00tUser','poundworld');

if(mysqli_connect_errno($connect))
{
		echo 'Failed to connect';
}

?>